#!/bin/bash
# ─────────────────────────────────────────────────────────────
# IITDH Attendance System — Boot Launcher
# Activates the Python venv and starts the main attendance code.
#
# Called by:  systemd service (attendance.service)
# ─────────────────────────────────────────────────────────────

ENV_DIR="/home/bio_user_iitdh/new_env"
MAIN_SCRIPT="$ENV_DIR/01marchrunningcode.py"
LOG_FILE="$ENV_DIR/logs/attendance.log"

# Create logs directory if it doesn't exist
mkdir -p "$ENV_DIR/logs"

echo "========================================"  | tee -a "$LOG_FILE"
echo "  IITDH Attendance System Starting..."    | tee -a "$LOG_FILE"
echo "  $(date)"                                | tee -a "$LOG_FILE"
echo "========================================"  | tee -a "$LOG_FILE"

# Move into the environment directory
cd "$ENV_DIR" || { echo "❌ Cannot find $ENV_DIR" | tee -a "$LOG_FILE"; exit 1; }

# Activate the virtual environment
source "$ENV_DIR/bin/activate" || { echo "❌ Cannot activate venv" | tee -a "$LOG_FILE"; exit 1; }

echo "✅ Virtual environment activated" | tee -a "$LOG_FILE"
echo "✅ Python: $(which python3)"      | tee -a "$LOG_FILE"

# Run the main attendance script
# stdout + stderr both go to log file AND terminal
python3 "$MAIN_SCRIPT" 2>&1 | tee -a "$LOG_FILE"

EXIT_CODE=${PIPESTATUS[0]}
echo "⚠️  Main script exited with code: $EXIT_CODE  ($(date))" | tee -a "$LOG_FILE"
