"""
IITDH Attendance System — Secure Exit Handler
==============================================

Runs as a background daemon thread inside the main attendance script.
Listens for a secret keyword typed into the terminal, then prompts
for a password. On success, opens the desktop and exits cleanly.

USAGE — add these 3 lines near the top of 01marchrunningcode.py:
─────────────────────────────────────────────────────────────────
    from exit_handler import ExitHandler
    exit_handler = ExitHandler()
    exit_handler.start()
─────────────────────────────────────────────────────────────────

EXIT FLOW:
  1. Type  "exit"  (or whatever SECRET_KEYWORD is set to) + Enter
  2. Password prompt appears
  3. Type the exit password → Enter
  4. Correct  → desktop opens, script exits with code 0
                (systemd will NOT restart — Restart=on-failure)
  5. Wrong    → "Access denied", attendance app continues running

TO CHANGE THE PASSWORD:
  Run this in terminal:
      python3 -c "import hashlib; print(hashlib.sha256('YOUR_NEW_PW'.encode()).hexdigest())"
  Paste the output as the EXIT_PASSWORD_HASH value below.

HEADLESS / GPIO BUTTON (future):
  When you remove the monitor, replace the _listen_keyboard() thread
  with a GPIO button handler that calls self._trigger_exit_prompt().
  The password check and exit logic stays identical.
"""

import hashlib
import os
import subprocess
import sys
import threading
import time

# ─────────────────────────────────────────────
# CONFIGURATION — change these as needed
# ─────────────────────────────────────────────

# Secret keyword typed in terminal to trigger the password prompt
# Keep it short but not something that appears in normal operation
SECRET_KEYWORD = "exit"

# SHA256 hash of the exit password
# Default password: IITDH@2025
# To generate a new hash:
#   python3 -c "import hashlib; print(hashlib.sha256('YOUR_PW'.encode()).hexdigest())"
EXIT_PASSWORD_HASH = "ee3dbd86c34f632b2a2b28c493990eed714e81b09133dbb6ad2507b8dd4647f3"

# How many wrong attempts before locking out (resets when correct)
MAX_ATTEMPTS = 3

# Lockout duration in seconds after MAX_ATTEMPTS wrong tries
LOCKOUT_SECONDS = 30


# ─────────────────────────────────────────────
# EXIT HANDLER
# ─────────────────────────────────────────────

class ExitHandler:
    """
    Background thread that monitors for the secret exit keyword.
    Instantiate and call .start() once at the top of your main script.
    """

    def __init__(self):
        self._thread = threading.Thread(
            target=self._listen_keyboard,
            name="ExitHandler",
            daemon=True          # dies automatically if main script exits
        )
        self._locked_until = 0   # epoch time when lockout expires

    def start(self):
        self._thread.start()
        print("[ExitHandler] Running — type the keyword to trigger secure exit")

    # ── PRIVATE ───────────────────────────────

    def _listen_keyboard(self):
        """Blocking loop: reads stdin line by line, waits for SECRET_KEYWORD."""
        while True:
            try:
                line = sys.stdin.readline()
                if not line:            # EOF / stdin closed
                    time.sleep(1)
                    continue
                if line.strip().lower() == SECRET_KEYWORD.lower():
                    self._trigger_exit_prompt()
            except Exception:
                time.sleep(1)

    def _trigger_exit_prompt(self):
        """Show password prompt. Called when keyword is detected."""

        # Check lockout
        now = time.time()
        if now < self._locked_until:
            remaining = int(self._locked_until - now)
            print(f"\n🔒 Too many failed attempts. Locked for {remaining}s.")
            return

        print("\n" + "=" * 50)
        print("  SECURE EXIT — IITDH Attendance System")
        print("=" * 50)

        attempts = 0
        while attempts < MAX_ATTEMPTS:
            try:
                import getpass
                password = getpass.getpass("  Enter exit password: ")
            except (EOFError, KeyboardInterrupt):
                print("\n  Exit cancelled.")
                return

            if self._check_password(password):
                self._do_exit()
                return
            else:
                attempts += 1
                remaining_tries = MAX_ATTEMPTS - attempts
                if remaining_tries > 0:
                    print(f"  ❌ Wrong password. {remaining_tries} attempt(s) left.")
                else:
                    self._locked_until = time.time() + LOCKOUT_SECONDS
                    print(f"  🔒 Access denied. Locked for {LOCKOUT_SECONDS}s.")
                    print("  Attendance system continuing...\n")

    def _check_password(self, entered: str) -> bool:
        """Hash the entered password and compare to stored hash."""
        entered_hash = hashlib.sha256(entered.encode()).hexdigest()
        return entered_hash == EXIT_PASSWORD_HASH

    def _do_exit(self):
        """Authenticated exit — open desktop, then exit cleanly."""
        print("\n  ✅ Access granted. Exiting attendance system...")
        print("=" * 50)

        # Small pause so any ongoing fingerprint op can finish
        time.sleep(1)

        # Open the desktop GUI
        # On Raspberry Pi OS Desktop this brings back the full GUI
        try:
            subprocess.Popen(
                ["bash", "-c", "DISPLAY=:0 startx &"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL
            )
        except Exception as e:
            print(f"  ⚠️  Could not open desktop: {e}")

        # ── HEADLESS NOTE ──────────────────────────────────────────
        # When you remove the monitor (OLED-only mode), replace the
        # subprocess.Popen above with whatever maintenance mode you
        # need — e.g. just open an SSH-accessible shell, or nothing.
        # ──────────────────────────────────────────────────────────

        print("  Goodbye. Closing attendance system.")

        # Exit with code 0 — systemd Restart=on-failure will NOT restart
        os._exit(0)


# ─────────────────────────────────────────────
# QUICK TEST (run this file directly to verify)
# ─────────────────────────────────────────────

if __name__ == "__main__":
    print("ExitHandler test mode")
    print(f"  Secret keyword : '{SECRET_KEYWORD}'")
    print(f"  Default password: IITDH@2025")
    print()

    handler = ExitHandler()
    handler.start()

    # Simulate the attendance app running
    print("Simulating attendance app... (type 'exit' to test the exit flow)")
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\nTest ended.")
